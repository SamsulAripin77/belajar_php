berikut ini adalah step-by-step crud dengan codeigneter
sumber referensi : https://bahasaweb.com/tutorial-crud-codeigniter-sederhana-dan-mudah/
note : pastikan codeigneter sudah siap !!!!

 	A : configurasi
		 a. buat database user di mysql
		 	field : nama,jk,tanggal_lahir,umur
		 b. buka file config/database di ci lalu isi sesuaikan 	   dengan database kita
		 c. masuk ke folder config/autoload.php
		 	tambahkankan librararies(database,session)
		 				 helper(url)
	B : selanjutnya kita akan mebuat crud nya
		step 1 : buat folde baru di direktory application/views 
				 dengan nama layouts lalu dalam folder layouts 
				 buatlah file dengan nama header_view.php -> check file header_view.php
