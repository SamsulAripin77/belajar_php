<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserController extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('UserModel');
    }

	public function index()
	{
        $data['all_user'] = $this->UserModel->all();
        $this->load->view('layouts/header_view');
        $this->load->view('list_user_view',$data);
        $this->load->view('layouts/footer_view');
    }
    
    public function create()
    {
        $this->load->view('layouts/header_view');
        $this->load->view('add_user_view');
        $this->load->view('layouts/footer_view');
    }

    public function store() 
    {
        $data = array (
            'nim' => $this->input->post('nim'),
            'nama' => $this->input->post('nama'),
            'alamat' => $this->input->post('alamat'),
            'angkatan' => $this->input->post('angkatan'),
            'telepon' => $this->input->post('telepon'),
        );

       if($this->UserModel->store($data) == TRUE )
        {
          echo "berhasil";
            $this->session->set_flashdata('store','true');
        }
        else {
            echo "gagal";
            $this->session->set_flashdata('store','false');
        }

        redirect(base_url());
    }

    public function test()
    {
        echo "test dari tombol";
    }

    public function edit($id) 
    {
        $data['title'] = 'saya';
        $data['user'] = $this->UserModel->show($id)->row();
        $this->load->view('layouts/header_view');
        $this->load->view('edit_user_view',$data);
        $this->load->view('layouts/footer_view');
    }

    public function update($id)
    {
        $data = array (
            'nim' => $this->input->post('nim'),
            'nama' => $this->input->post('nama'),
            'alamat' => $this->input->post('alamat'),
            'angkatan' => $this->input->post('angkatan'),
            'telepon' => $this->input->post('telepon')
        );

       if($this->UserModel->update($data,$id) == TRUE )
        {
            $this->session->set_flashdata('update','true');
        }
        else {
            $this->session->set_flashdata('update','false');
        }

        redirect(base_url());
    }
    

    public function delete($id)     
    {
       if($this->UserModel->delete($id)  == TRUE)
       {
        $this->session->set_flashdata('hapus',TRUE);
       }
       else
       {
        $this->session->set_flashdata('hapus',false);
       }
       
       redirect(base_url());
    }

    
}
