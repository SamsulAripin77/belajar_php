<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UserModel extends CI_Model 
{
    public function __construct()
    {
        parent::__construct();
    }

    public function all()
    {
        $this->db->select('*');
        $this->db->from('mahasiswa');
        $this->db->order_by('id','ASC');

        return $this->db->get();
    }

    public function store($data)
    {
        $this->db->insert('mahasiswa',$data);
        return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
    }

    public function show($id)
    {
        $this->db->select('*');
        $this->db->from('mahasiswa');
        $this->db->where('id',$id);

        return $this->db->get();
    }

    public function update($data, $id)
    {
        $this->db->update('mahasiswa',$data,array('id' => $id));
        return ($this->db->affected_rows()>0) ? TRUE : FALSE;

    }

    public function delete($id)
    {
        $this->db->delete('mahasiswa', array('id' => $id));
        return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
    }
    
}