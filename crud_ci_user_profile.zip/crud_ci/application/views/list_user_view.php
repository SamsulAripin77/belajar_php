<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="header">
</div>
<?php if($this->session->flashdata('store')): ?>
     <?php if($this->session->flashdata('store') == TRUE): ?>
          <div class="alert alert-success">Berhasil menambahkan pengguna baru</div>
     <?php elseif($this->session->flashdata('store') == FALSE): ?>
          <div class="alert alert-danger">Gagal menambahkan pengguna baru</div>
     <?php endif; ?>
<?php endif; ?>
<?php if($this->session->flashdata('update')): ?>
     <?php if($this->session->flashdata('update') == TRUE): ?>
          <div class="alert alert-success">Berhasil merubah pengguna</div>
     <?php elseif($this->session->flashdata('update') == FALSE): ?>
          <div class="alert alert-danger">Gagal merubah pengguna</div>
     <?php endif; ?>
<?php endif; ?>
<?php if($this->session->flashdata('hapus')): ?>
     <?php if($this->session->flashdata('hapus') == TRUE): ?>
          <div class="alert alert-success">Berhasil menghapus pengguna</div>
     <?php elseif($this->session->flashdata('hapus') == FALSE): ?>
          <div class="alert alert-danger">Gagal menghapus pengguna </div>
     <?php endif; ?>
<?php endif; ?>
<div>
    <div class="row">
        <div class="pull-left">
            <h3>Daftar Pengguna</h3> 
        </div>
        <div class="pull-right">
            <a class="btn btn-default btn-tambah" href="<?php echo base_url('user/create');?>" type="button">Tambah Pengguna</a>
        </div>
    </div>
    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>nim</th>
                <th>nama</th>
                <th>alamat</th>
                <th>angkatan</th>
                <th>telepon</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $no =1; ?>
            <?php foreach($all_user->result() as $user) : ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $user->nim; ?></td>
                    <td><?php echo $user->nama; ?></td>
                    <td><?php echo $user->alamat; ?></td>
                    <td><?php echo $user->angkatan; ?></td>
                    <td><?php echo $user->telepon; ?></td>
                    <td>
                        <a class="btn btn-default" href="<?php echo base_url('user/edit/'.$user->id); ?>">Edit</a>
                        <a class="btn btn-danger"  href="<?php echo base_url('user/delete/'. $user->id); ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>