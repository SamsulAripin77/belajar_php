<footer>
    Copyright &copy; <?php echo date('Y'); ?> . Simple_Crud
</footer>
</body>
</html>