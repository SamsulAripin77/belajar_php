<!-- 

step 1 : nah ini adalah step pertama kita membuat header terpisah dengan footer dan body html agar kita tidak terus mengulang ulang membuat header di semua halaman view yang ada cukup kita load halaman header ini saja

 -->
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Simple_crud</title>
    <style type="text/css">

		body {
      /* membuat content berada di tengah halaman dengna lebar 50% dari lebar layar */
			width: 50%;
			margin: 0 auto;
		}

    h1.judul {
      /* membuat tag h1 yang mempunyai class=judul agar perataanya rata tengah */
      text-align: center;
    }
    .header{
      position: relative;
      margin-bottom: 20px;
    }
		
    .header:before,
    .header:after {
      display: table;
      content: ''
    }
    .header:after {
      clear:both;
    }
    .header .title {
      float:left;
    }
    .pull-right {
      text-align: right;
    }
    .header .title {
      padding: 0;
      margin: 0;
    }
    .header .action {
      float:right;
    }

    .btn {
      display: inline-block;
      padding: 2px 5px;
      margin-bottom :0;
      font-size: 14px;
      color :#333;
      text-align: center;
      vertical-align: middle;
      cursor: pointer;
      background-color: #ffffff;
      -webkit-border-radius: 3px;
      -webkit-border-radius: 3px;
      -webkit-border-radius: 3px;
      background-image: none !important;
      text-shadow:olivedrab;
      box-shadow: none;
      transition: all 0.12s linear 0s !important;
      font : 14px/20px "Helvetica Neue",Helvetica,Arial,sans-serif;
      text-decoration: none
    }

    .btn-default {
      color :seashell;
      background-color :orange;
      padding-right: 3px;
      padding-left: 3px;
    }
    .btn-danger {
      color :cornsilk;
      background-color :crimson;
    }
    .btn-default,.btn-danger {
      text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
      -webkit-box-shadow: insert 0 1px 0 rgba(255,255,255,0.15),0 1px 1px rgba(0,0,0,0.075);
      box-shadow: insert 0 1px 0 rgba(255,255,255,0.15),0 1px 1px rgba(0,0,0,0.075);
      padding: 5px;

    }

    .form-group {
      margin-bottom: 20px;
    }
    .form-group label {
      display: block;

      margin-bottom: 5px;
    }
    input[type="text"],
    input[type="date"],
    input[type="number"] {
      box-sizing: border-box;
      width:100%;
      border: 1px solid #cccccc;
      padding: 10px;
      border-radius: 3px;
      display: block;
    }
    table {
      width: 100%;
      border-spacing: 0;
    }
    table tr th,
    table tr td {
      padding: 5px;
    }
    table thead {
      background-color: #333333;
    }
    table thead tr th {
      color: #ffffff;
      border-top: 1px solid #000000;
      border-right:1px solid #000000;
      border-bottom: 1px solid #000000;
      text-align: center;
    }
    table thead tr th:first-child {
      border-left: 1px solid #000000;
    }
    table tbody tr td:first-child {
      border-left: 1px solid #555555;
    }

    footer {
      margin-top: 20px;
      color: #999999;
      text-align: center;
    }
    .btn-tambah {
      margin: 7px;
      padding: 7px;
      color: #000000;
      font-family: arial;
    }
    .btn-ok {
      display: inline-block;
    font-size: 14px;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    -webkit-border-radius: 3px;
    background-image: none !important;
    box-shadow: none;
    transition: all 0.12s linear 0s !important;
    font: 14px/20px "Helvetica Neue",Helvetica,Arial,sans-serif;
    text-decoration: none;
    background-color: orange;
    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
    margin: 7px;
    padding: 7px;
    color: #000000;
    font-family: arial;
    }
    .float-left {
      float: left;
      text-align :center;
    }

    .alert {
      border-width: 1px;
      border-color: #555555;
      border-style: solid;
      padding : 10px 15px;
      margin-bottom: 15px;
      border-radius: 3px;
    }
    .alert.alert-success {
      color: #155724;
      background-color: #d4edda;
      border-color: #c3e6cb;
    }
    </style>
</head>
<body>
<h1 class="judul">BELAJAR CRUD DENGAN CODEIGNITER</h1>