<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php if($this->session->flashdata('store')): ?>
     <?php if($this->session->flashdata('store') == TRUE): ?>
          <div class="alert alert-success">Berhasil menambahkan pengguna baru</div>
     <?php elseif($this->session->flashdata('store') == FALSE): ?>
          <div class="alert alert-danger">Gagal menambahkan pengguna baru</div>
     <?php endif; ?>
<?php endif; ?>

<div class="header">
    <div class="title">Tambah Pengguna</div>
    <br>
    <form action="<?php echo base_url('user/store');?>" method="post" id="add_user">
        <div class="form-group">
            <label for="nim">NIM</label>
            <input type="text" name="nim" id="nama">
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" name="nama" id="nama">
        </div>
        <div class="form-group">
            <label for="alamat">alamat</label>
            <input type="text" name="alamat" id="nama">
        </div>
        <div class="form-group">
            <label for="angkatan">angkatan</label>
            <input type="text" name="angkatan" id="nama">
        </div>
        <div class="form-group">
            <label for="telepon">telepon</label>
            <input type="text" name="telepon" id="nama">
        </div>
        <div class="float-left">
        <button type="submit" class="btn btn-default">
        Tambah Pengguna
        </button>
        <a href="<?php echo base_url() ?>" class="btn btn-danger">Kembali</a>
        </div>

    </form>
</div>